"""Fail loudly when source-recalculated coefficients differ from documented snapshots."""
import pandas as pd
from common import OUT, ROOT
main=OUT/'main_models.csv'
if not main.exists():raise SystemExit('No computed FE results. Supply data and run main models first.')
repro=pd.read_csv(main)
snap=pd.read_csv(ROOT/'documented_results'/'focal_coefficient_snapshot.csv')
rows=[]
for _,s in snap.iterrows():
    q=repro[(repro.outcome==s.outcome)&(repro.spec==s.spec)&(repro.term==s.term)]
    if len(q)!=1:
        rows.append({**s.to_dict(),'reproduced':float('nan'),'abs_diff':float('nan'),'pass':False})
        continue
    val=float(q.iloc[0].coef);diff=abs(val-float(s.documented_coef))
    rows.append({**s.to_dict(),'reproduced':val,'abs_diff':diff,'pass':diff<=float(s.tolerance)})
result=pd.DataFrame(rows);result.to_csv(OUT/'snapshot_check.csv',index=False)
print(result.to_string(index=False))
if not result['pass'].all():raise SystemExit('FAIL: mismatch with originally documented study coefficients. Reconcile inputs and decisions rather than overwriting original snapshots.')
print('PASS: all checked documented coefficients within stated numeric tolerance')
