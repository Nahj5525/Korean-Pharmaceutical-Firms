"""Optional one-year-forward forecasting (REQUIRES original inputs).

Only fiscal-year t predictors predict outcomes in year t+1; source document
filing dates must precede t+1 year-end. ALL preprocessing/quantiles/model tuning
are fit within each chronological train fold. Firm-block bootstrap is paired on
identical test firm-years; it never creates fake empirical results.

This is an optional audit, not a finding reported in the revised manuscript.
"""
from __future__ import annotations
import argparse
import warnings
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator,TransformerMixin,clone
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import ElasticNet
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
from sklearn.model_selection import ParameterGrid
from common import DATA,OUT,CONTROLS,EXECUTIVE,require_columns
try:
    from xgboost import XGBRegressor
except ImportError:
    XGBRegressor=None

class TrainWinsorizer(BaseEstimator,TransformerMixin):
    """Training-only 1/99 percentile clipping; prevents forward-quantile leakage."""
    def fit(self,X,y=None):
        a=np.asarray(X,dtype=float)
        self.low_=np.nanquantile(a,0.01,axis=0)
        self.high_=np.nanquantile(a,0.99,axis=0)
        return self
    def transform(self,X):
        return np.clip(np.asarray(X,dtype=float),self.low_,self.high_)

def models():
    result={
      'ElasticNet':(ElasticNet(max_iter=10000),{'model__alpha':[0.01,0.1], 'model__l1_ratio':[0.2,0.8]}),
      'RandomForest':(RandomForestRegressor(n_estimators=150,random_state=420,n_jobs=1),{'model__max_depth':[3,None], 'model__min_samples_leaf':[3,6]})}
    if XGBRegressor:
        result['XGBoost']=(XGBRegressor(n_estimators=120,random_state=420,n_jobs=1,objective='reg:squarederror',verbosity=0),
                           {'model__max_depth':[2,4],'model__learning_rate':[0.03,0.1]})
    return result

def estimator(base,par):
    pipe=Pipeline([('imputer',SimpleImputer(strategy='median')),
                   ('winsor',TrainWinsorizer()),('scale',StandardScaler()),
                   ('model',clone(base))])
    return pipe.set_params(**par)

def load_strict_panel():
    src=DATA/'analysis_panel_raw.csv'
    if not src.exists():raise SystemExit('Authorized original analysis_panel_raw.csv is required')
    d=pd.read_csv(src,dtype={'firm_id':str,'stock_code':str})
    require_columns(d,['firm_id','year','ROA','TQ','RDINT']+CONTROLS+EXECUTIVE)
    if d.duplicated(['firm_id','year']).any():
        raise SystemExit('Resolve duplicate firm-years before prediction; original choices cannot be assumed')
    d['year']=pd.to_numeric(d.year,errors='raise').astype(int)
    d=d.sort_values(['firm_id','year']).reset_index(drop=True)
    d['target_year']=d.year+1
    for y in ['ROA','TQ']:
        d['TARGET_'+y]=d.groupby('firm_id')[y].shift(-1)
        next_year=d.groupby('firm_id').year.shift(-1)
        d.loc[next_year.ne(d.target_year),'TARGET_'+y]=np.nan
    # fiscal year t features predict fiscal year t+1, with no target year t+1 fields.
    t=OUT/'text_panel.csv'
    if t.exists():
        x=pd.read_csv(t,dtype={'firm_id':str})
        d=d.merge(x,on=['firm_id','year'],how='left',validate='one_to_one')
    return d

def cohort_sets(d,y):
    fundamentals=[y,'RDINT']+CONTROLS
    basics=fundamentals+EXECUTIVE
    require_columns(d,fundamentals+EXECUTIVE)
    yield 'panel', d[d['TARGET_'+y].notna()].copy(), {'fundamentals':fundamentals,'plus_executives':basics}
    text=['BUS_TONE','LN_BUS_SENT1','LN_BUS_RISK1','LN_BUS_RND1','BUS_SECTIONS','BUS_CONF']
    if not set(text+['last_filing_date']).issubset(d):
        print('Text future-outcome cohort SKIPPED: date-audited, complete text columns absent')
        return
    dd=d[d['TARGET_'+y].notna()].copy()
    dd['last_filing_date']=pd.to_datetime(dd.last_filing_date,errors='coerce')
    cutoff=pd.to_datetime(dd.target_year.astype(str)+'-12-31')
    dd=dd[(dd[text].notna().all(axis=1)) & dd.last_filing_date.notna() & (dd.last_filing_date<=cutoff)].copy()
    if len(dd)<40:
        print('Text future-outcome cohort SKIPPED: too few filing-date-valid rows')
        return
    yield 'text_dated',dd,{'fundamentals':fundamentals,'plus_executives':basics,
                           'plus_text':fundamentals+text,'all_blocks':basics+text}

def tuning_fit(train,val,columns,y,base,grid):
    target='TARGET_'+y
    # Tuned by prior-year validation, never the test year.
    if len(train)<20 or len(val)<5:return None
    best=(-float('inf'),None)
    for par in ParameterGrid(grid):
        model=estimator(base,par)
        model.fit(train[columns],train[target])
        predictions=model.predict(val[columns])
        score=-float(np.mean((val[target].to_numpy()-predictions)**2))
        if score>best[0]:best=(score,par)
    return best[1]

def pairwise_bootstrap(preds,n_boot=999,seed=420):
    """Bootstrap *firms*, keeping all their test years together."""
    rng=np.random.default_rng(seed);out=[]
    keys=['outcome','cohort','model']
    for (y,cohort,model),group in preds.groupby(keys,sort=True):
        baseline=group[group.feature_set=='fundamentals'][['firm_id','target_year','actual','prediction']].rename(columns={'prediction':'base_pred'})
        for feature,augment in group[group.feature_set!='fundamentals'].groupby('feature_set'):
            merged=baseline.merge(augment[['firm_id','target_year','prediction']],on=['firm_id','target_year'],how='inner',validate='one_to_one')
            if len(merged)<5:continue
            firms=merged.firm_id.unique()
            delta=[]
            for rep in range(n_boot+1):
                if rep==0:
                    idx=np.arange(len(merged))
                else:
                    sampled=rng.choice(firms,size=len(firms),replace=True)
                    idx=np.concatenate([np.where(merged.firm_id.to_numpy()==f)[0] for f in sampled])
                act=merged.actual.to_numpy()[idx]
                ss_tot=np.sum((act-act.mean())**2)
                if ss_tot<=0:continue
                s0=np.sum((act-merged.base_pred.to_numpy()[idx])**2)
                s1=np.sum((act-merged.prediction.to_numpy()[idx])**2)
                delta.append((s0-s1)/ss_tot)
            if not delta:continue
            out.append({'outcome':y,'cohort':cohort,'model':model,'augment':feature,
                        'test_firm_years':len(merged),'firms':len(firms),
                        'delta_oos_R2':delta[0],
                        'firm_boot_ci_low':np.quantile(delta[1:],0.025) if len(delta)>1 else np.nan,
                        'firm_boot_ci_high':np.quantile(delta[1:],0.975) if len(delta)>1 else np.nan,
                        'bootstrap_draws':n_boot})
    return pd.DataFrame(out)

def rolling(d,n_boot=999):
    rows=[]
    for y in ['ROA','TQ']:
        for cohort,frame,sets in cohort_sets(d,y):
            for test in range(2020,2025):
                train=frame[frame.target_year<=test-2]
                val=frame[frame.target_year==test-1]
                future=frame[frame.target_year==test]
                if min(len(train),len(val),len(future))<5:continue
                refit=frame[frame.target_year<=test-1]
                for features,columns in sets.items():
                    for modelname,(base,grid) in models().items():
                        par=tuning_fit(train,val,columns,y,base,grid)
                        if par is None:continue
                        m=estimator(base,par).fit(refit[columns],refit['TARGET_'+y])
                        pred=m.predict(future[columns])
                        for fid,actual,predicted in zip(future.firm_id,future['TARGET_'+y],pred):
                            rows.append({'outcome':y,'cohort':cohort,'target_year':test,'firm_id':fid,
                             'feature_set':features,'model':modelname,
                             'actual':float(actual),'prediction':float(predicted),
                             'training_max_target_year':int(refit.target_year.max()),
                             'source_features_max_year':test-1,'selected_params':str(par)})
    prediction=pd.DataFrame(rows)
    if prediction.empty:raise SystemExit('No valid chronological forecasts from current data')
    prediction.to_csv(OUT/'rolling_predictions_forward_one_year.csv',index=False)
    intervals=pairwise_bootstrap(prediction,n_boot=n_boot)
    intervals.to_csv(OUT/'rolling_paired_firm_block_bootstrap.csv',index=False)
    print('Out-of-time predictions',len(prediction),'paired comparisons',len(intervals))
    return prediction

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--bootstrap-reps',type=int,default=999)
    args=parser.parse_args()
    rolling(load_strict_panel(),n_boot=args.bootstrap_reps)
