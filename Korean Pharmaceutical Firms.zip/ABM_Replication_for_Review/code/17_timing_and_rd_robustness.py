"""Temporal and denominator-robustness extensions based ONLY on real panel.

The asset-asset shared denominator is not fixed by re-parameterizing the same
R&D/assets ratio. Lagged R&D changes the accounting reference date; MTB uses
a different valuation denominator; neither substitutes R&D/sales. An actual
R&D/sales test still requires independently sourced R&D expenditure and sales.
"""
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from common import OUT,CONTROLS,EXECUTIVE,fit_fe

d=pd.read_csv(OUT/'analysis_panel_prepared.csv',dtype={'firm_id':str}).sort_values(['firm_id','year']).reset_index(drop=True)
rows=[]
def add(model,study,outcome,term,notation,df):
    if term not in model.params:raise ValueError(term)
    ci=model.conf_int().loc[term]
    rows.append(dict(study=study,outcome=outcome,term=term,specification=notation,
        coef=float(model.params[term]),se=float(model.bse[term]),t=float(model.tvalues[term]),
        p=float(model.pvalues[term]),ci_lower=float(ci.iloc[0]),ci_upper=float(ci.iloc[1]),
        nobs=int(model.nobs),nfirms=int(df.firm_id.nunique())))
def clustered(formula,dd):
    lm=smf.ols(formula,data=dd,missing='drop')
    groups=dd.loc[lm.data.row_labels,'firm_id']
    return lm.fit(cov_type='cluster',cov_kwds={'groups':groups})
# Prior-year R&D ratios are not mechanically divided by t's year-end assets.
prior=d.groupby('firm_id',sort=False)
d['L1_RDINT_Z']=prior.RDINT_Z.shift(1).where(prior.year.diff().eq(1))
d['PHD_x_L1RD']=d.PHD*d.L1_RDINT_Z
d['SINGLE_x_L1RD']=d.SINGLE*d.L1_RDINT_Z
eligible=d.dropna(subset=['L1_RDINT_Z']).copy()
for outcome in ['TQ','MB']:
    terms=EXECUTIVE+['L1_RDINT_Z','SINGLE_x_L1RD','PHD_x_L1RD']+CONTROLS+['C(firm_id)','C(year)']
    m=clustered(outcome+' ~ '+' + '.join(terms),eligible)
    add(m,'prior_year_rd',outcome,'PHD_x_L1RD','lagged R&D/assets x current PHD; firm+year FE',eligible)
    add(m,'prior_year_rd',outcome,'PHD','lagged R&D/assets x current PHD; firm+year FE',eligible)
# Model fiscal t+1 outcomes using fiscal t predictors, *calendar-adjacent* observations.
# Estimated fixed effects indexed by base-year t; not causal and possible persistent omitted variables.
for outcome,term in [('ROA','SINGLE'),('ROE','SINGLE'),('TQ','PHD'),('MB','PHD')]:
    d['F1_'+outcome]=prior[outcome].shift(-1).where(prior.year.shift(-1).eq(d.year+1))
    f1=d.dropna(subset=['F1_'+outcome]).copy()
    m=fit_fe(f1,'F1_'+outcome,interactions=(term=='PHD'))
    add(m,'next_year_outcome','F1_'+outcome,term,'year-t X, fiscal t+1 outcome; firm+year FE',f1)
    # status changes are endogenous: lagged outcome is not included to avoid mechanical Nickell concerns.
    if term=='PHD':
        add(m,'next_year_outcome','F1_'+outcome,'PHD_X_RDINT','year-t X, fiscal t+1 outcome; firm+year FE',f1)
# Lagged realized outcome as selection predictor, not causal identification.
for outcome,term in [('ROA','SINGLE'),('TQ','PHD')]:
    d['L1_'+outcome]=prior[outcome].shift(1).where(prior.year.diff().eq(1))
    elig=d.dropna(subset=['L1_'+outcome]).copy()
    # Use only truly previous, calendar-consecutive controls.
    for c in CONTROLS:
        d['L1_'+c]=prior[c].shift(1).where(prior.year.diff().eq(1))
    elig=d.dropna(subset=['L1_'+outcome]+['L1_'+c for c in CONTROLS]).copy()
    m=clustered(term+' ~ L1_'+outcome+' + '+' + '.join('L1_'+c for c in CONTROLS)+' + C(firm_id) + C(year)',elig)
    add(m,'reverse_selection',term,'L1_'+outcome,'prior accounting or Q predicts present status',elig)
# Next-year representative status as a placebo for current firm outcome.
for outcome,term in [('ROA','SINGLE'),('TQ','PHD')]:
    d['F1_'+term]=prior[term].shift(-1).where(prior.year.shift(-1).eq(d.year+1))
    elig=d.dropna(subset=['F1_'+term]).copy()
    m=fit_fe(elig,outcome,interactions=(term=='PHD'),extra_terms=['F1_'+term])
    add(m,'future_status_placebo',outcome,'F1_'+term,'future (t+1) status controls current outcome',elig)
# In model predicting TQ with current RD, MB alternative has different denominator.
for outcome in ['TQ','MB']:
    m=fit_fe(d,outcome,interactions=True)
    add(m,'baseline_moderation',outcome,'PHD_X_RDINT','current R&D/assets, no alternative numerator data',d)
res=pd.DataFrame(rows)
res.to_csv(OUT/'timing_rd_sensitivity.csv',index=False)
print(res[['study','outcome','term','coef','p','nobs','nfirms']].round(5).to_string(index=False))
