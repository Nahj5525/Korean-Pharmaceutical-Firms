import pandas as pd
from common import OUT, fit_fe, tidy_model

src = OUT / "analysis_panel_prepared.csv"
if not src.exists():
    raise SystemExit("Run 01_prepare_analysis_panel.py first")
df = pd.read_csv(src)
keep = ["SINGLE","PHD","BUS","LONGTEN","RDINT_Z","SINGLE_X_RDINT","PHD_X_RDINT","SIZE","LEV","CUR","GRW","CFO","FORN","LARGEST","BIG4","LOSS"]
rows=[]
for y in ["ROA","ROE","TQ","MB"]:
    for spec, inter in [("main",False),("interaction",True)]:
        m=fit_fe(df,y,interactions=inter)
        t=tidy_model(m, keep=[k for k in keep if k in m.params.index])
        t.insert(0,"outcome",y); t.insert(1,"spec",spec)
        rows.append(t)
pd.concat(rows, ignore_index=True).to_csv(OUT/"main_models.csv", index=False)
print("Wrote outputs/main_models.csv")
