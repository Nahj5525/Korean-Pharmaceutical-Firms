"""Re-estimate R&D moderation using expenditure/sales when actual source items exist.
Not executable from ratio-only data and not represented as a completed result.
"""
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from common import DATA, OUT, CONTROLS, winsorize_series
src=DATA/'analysis_panel_raw.csv'
if not src.exists():raise SystemExit('No authorized firm-year panel')
d=pd.read_csv(src,dtype={'firm_id':str})
if not {'RD_EXP','SALES'}.issubset(d):
    raise SystemExit('RD_EXP and SALES accounting source items required; no proxy fabricated from RDINT.')
if d.duplicated(['firm_id','year']).any():
    raise SystemExit('Resolve source duplicate firm-years prior to alternative denominator analysis')
d=d[(d.SALES>0)&(d.RD_EXP>=0)].copy()
if len(d)<50:raise SystemExit('Too few usable R&D/sales cases')
d['RD_SALES']=winsorize_series(d.RD_EXP/d.SALES)
sd=d.RD_SALES.std(ddof=1)
if sd==0:raise SystemExit('No RD_SALES variation')
d['RD_SALES_Z']=(d.RD_SALES-d.RD_SALES.mean())/sd
d['PHD_X_RD_SALES']=d.PHD*d.RD_SALES_Z
d['SINGLE_X_RD_SALES']=d.SINGLE*d.RD_SALES_Z
rows=[]
for y in ['TQ','MB']:
    terms=['SINGLE','PHD','BUS','LONGTEN','RD_SALES_Z','SINGLE_X_RD_SALES','PHD_X_RD_SALES']+CONTROLS+['C(firm_id)','C(year)']
    base=smf.ols(y+' ~ '+' + '.join(terms),data=d,missing='drop')
    groups=d.loc[base.data.row_labels,'firm_id']
    m=base.fit(cov_type='cluster',cov_kwds={'groups':groups})
    rows.append({'outcome':y,'term':'PHD_X_RD_SALES','coef':m.params['PHD_X_RD_SALES'],
      'p':m.pvalues['PHD_X_RD_SALES'],'t':m.tvalues['PHD_X_RD_SALES'],
      'nobs':int(m.nobs),'n_firms':int(groups.nunique())})
pd.DataFrame(rows).to_csv(OUT/'alternative_rd_denominator.csv',index=False)
print('Computed real-input R&D/sales sensitivity; check retained sample vs principal panel')
