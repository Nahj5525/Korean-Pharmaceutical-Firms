"""Retain author hand-coded values; produce a **review checklist** only.

Automatic secondary records neither overwrite author values nor validate a
specific fiscal-year reference date unless supporting filings are available.
"""
import pandas as pd
from common import OUT,ROOT
p=ROOT/'audit'/'opendart_partial_qa_firmyears.csv'
d=pd.read_csv(p,dtype={'stock_code':str})
x=d.loc[d.verification_status.eq('VERIFIED')].copy()
assert len(x)==18
x['needs_single_review']=x['mismatch_SINGLE'].eq(1)
x['needs_phd_review']=x['mismatch_PHD'].eq(1)
x['concordant_measures']=~x['needs_single_review']&~x['needs_phd_review']
x['review_decision']='NOT ADJUDICATED; author codes retained'
x['author_filing_accession']=''
x['auxiliary_filing_accession']=''
x['same_reference_date']='NOT DOCUMENTED'
x['same_registered_roster']='NOT DOCUMENTED'
x['doctorate_awarded_confirmed']='NOT DOCUMENTED'
x['filing_amendment_checked']='NOT DOCUMENTED'
x['manual_resolution_notes']=''
cols=['panel_id','stock_code','year','SINGLE_old','SINGLE_corrected','PHD_old','ANY_PHD',
      'needs_single_review','needs_phd_review','concordant_measures','author_filing_accession',
      'auxiliary_filing_accession','same_reference_date','same_registered_roster',
      'doctorate_awarded_confirmed','filing_amendment_checked','review_decision','manual_resolution_notes']
x[cols].to_csv(OUT/'secondary_18_case_reconciliation_template.csv',index=False,encoding='utf-8-sig')
print('18 independent comparison records; SINGLE mismatches:',x.needs_single_review.sum(),
      'PHD mismatches:',x.needs_phd_review.sum(),
      'records with any mismatch:',(~x.concordant_measures).sum())
print('This output is only a reconciliation queue, not an adjudication or error-rate estimate.')
