"""Paired, SD-standardized cross-outcome slope differences under identical X.

OLS linearity implies regressing Z(Accounting)-Z(Market) on the same X yields
exactly beta_accounting/SD_accounting - beta_market/SD_market. Firm-clustered
covariance of this paired difference correctly allows cross-equation residual
correlation; no unsupported inference from significance versus nonsignificance.
"""
import pandas as pd
from statsmodels.stats.multitest import multipletests
from common import OUT,fit_fe

d=pd.read_csv(OUT/'analysis_panel_prepared.csv',dtype={'firm_id':str})
rows=[]
for a,b in [('ROA','TQ'),('ROE','MB'),('ROA','MB'),('ROE','TQ')]:
    for y in [a,b]:
        d['Z_'+y]=(d[y]-d[y].mean())/d[y].std(ddof=1)
    col='Z_'+a+'_minus_'+b
    d[col]=d['Z_'+a]-d['Z_'+b]
    for inter in [False,True]:
        m=fit_fe(d,col,interactions=inter)
        for term in ['SINGLE','PHD']+(['SINGLE_X_RDINT','PHD_X_RDINT'] if inter else []):
            if term not in m.params:continue
            beta,se=float(m.params[term]),float(m.bse[term])
            rows.append(dict(accounting=a,market=b,spec='interaction' if inter else 'main',term=term,
                             accounting_sd=float(d[a].std(ddof=1)),market_sd=float(d[b].std(ddof=1)),
                             beta_difference_standardized=beta, se=se,
                             ci_lower=beta-1.96*se,ci_upper=beta+1.96*se,
                             t=float(m.tvalues[term]),p=float(m.pvalues[term]),nobs=int(m.nobs),nfirms=int(d.firm_id.nunique())))
out=pd.DataFrame(rows)
# Prespecified six contrasts: two paired domains by three hypothesis tests.
core={'SINGLE':('main','SINGLE'), 'PHD':('main','PHD'), 'PHD_X_RDINT':('interaction','PHD_X_RDINT')}
selection=((out.accounting=='ROA')&(out.market=='TQ') | (out.accounting=='ROE')&(out.market=='MB')) & (
    ((out.spec=='main') & out.term.isin(['SINGLE','PHD'])) | ((out.spec=='interaction') & (out.term=='PHD_X_RDINT')))
core_df=out[selection].copy()
assert len(core_df)==6,len(core_df)
core_df['p_holm_six']=multipletests(core_df.p,method='holm')[1]
core_df['significant_holm_05']=core_df.p_holm_six<.05
out.to_csv(OUT/'direct_outcome_contrasts_full.csv',index=False)
core_df.to_csv(OUT/'direct_outcome_contrasts_primary_six.csv',index=False)
print('Paired SD-standardized contrasts:')
print(core_df[['accounting','market','spec','term','beta_difference_standardized','se','ci_lower','ci_upper','p','p_holm_six']].round(5).to_string(index=False))
# Unit check: computed difference in standardized single-outcome regressions.
for _,r in core_df.iterrows():
    z1=fit_fe(d,'Z_'+r.accounting,interactions=(r.spec=='interaction')).params[r.term]
    z2=fit_fe(d,'Z_'+r.market,interactions=(r.spec=='interaction')).params[r.term]
    assert abs((z1-z2)-r.beta_difference_standardized)<1e-8
print('Checked coefficient-contrast arithmetic with independent equations.')
