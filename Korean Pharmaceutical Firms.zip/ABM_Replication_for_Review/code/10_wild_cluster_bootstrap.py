"""Optional wild-cluster-bootstrap finite-cluster check, never guessed in absence of data."""
import argparse
import pandas as pd
import statsmodels.formula.api as smf
from common import OUT,fe_formula
try:
    from wildboottest.wildboottest import wildboottest
except ImportError as exc:
    raise SystemExit('Optional wildboottest missing. Install package dependencies.') from exc
parser=argparse.ArgumentParser()
parser.add_argument('--B',type=int,default=9999)
parser.add_argument('--seed',type=int,default=42)
args=parser.parse_args()
if not (OUT/'analysis_panel_prepared.csv').exists():raise SystemExit('Real authorized panel is needed')
d=pd.read_csv(OUT/'analysis_panel_prepared.csv',dtype={'firm_id':str})
focus=[('SINGLE_ROA','ROA',False,'SINGLE'),('SINGLE_ROE','ROE',False,'SINGLE'),
       ('PHD_TQ','TQ',False,'PHD'),('PHD_MB','MB',False,'PHD'),
       ('PHDxRD_TQ','TQ',True,'PHD_X_RDINT'),('PHDxRD_MB','MB',True,'PHD_X_RDINT')]
rows=[]
for label,y,inter,term in focus:
    base=smf.ols(fe_formula(y,interactions=inter),data=d,missing='drop')
    cluster=d.loc[base.data.row_labels,'firm_id']
    output=wildboottest(base,param=term,cluster=cluster,B=args.B,bootstrap_type='31',seed=args.seed)
    if not isinstance(output,pd.DataFrame) or output.empty:
        raise RuntimeError(f'Unexpected bootstrap output for {label}: {type(output)}')
    rec=output.iloc[0]
    stat=rec.get('statistic',float('nan'))
    p=rec.get('p-value',float('nan'))
    rows.append({'relationship':label,'spec':'interaction' if inter else 'main',
     'outcome':y,'term':term,'firms':cluster.nunique(),'draws':args.B,
     'bootstrap_type':'31','seed':args.seed,'statistic':stat,'p_wild_cluster':p})
out=OUT/'wild_cluster_bootstrap_focal.csv'
pd.DataFrame(rows).to_csv(out,index=False)
print('Wrote',out)
