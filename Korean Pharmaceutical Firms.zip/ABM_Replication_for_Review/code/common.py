"""Shared panel specifications; no observed values are embedded here."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
OUT=ROOT/'outputs'
OUT.mkdir(exist_ok=True)
CONTINUOUS=['ROA','ROE','TQ','MB','RDINT','SIZE','LEV','CUR','GRW','CFO','AGE','FORN','LARGEST']
CONTROLS=['SIZE','LEV','CUR','GRW','CFO','FORN','LARGEST','BIG4','LOSS']
EXECUTIVE=['SINGLE','PHD','BUS','LONGTEN']
BINARY=['SINGLE','PHD','BUS','LONGTEN','BIG4','LOSS']
MAIN_FIELDS=['ROA','ROE','TQ','MB','RDINT']+CONTROLS+EXECUTIVE

def require_columns(df, cols, label='data'):
    missing=[x for x in cols if x not in df.columns]
    if missing: raise ValueError(f'{label}: missing {missing}')

def winsorize_series(s,lo=0.01,hi=0.99):
    low,high=s.quantile([lo,hi]); return s.clip(low,high)

def prepare_panel(df):
    require_columns(df,['firm_id','year']+MAIN_FIELDS,'analysis panel')
    d=df.copy().sort_values(['firm_id','year']).reset_index(drop=True)
    if d[['firm_id','year']].isna().any().any() or d.duplicated(['firm_id','year']).any():
        raise ValueError('Every firm-year must have complete unique keys')
    d['firm_id']=d['firm_id'].astype(str)
    d['year']=pd.to_numeric(d['year'],errors='raise').astype(int)
    for v in CONTINUOUS:
        if v in d:
            d[v]=pd.to_numeric(d[v],errors='raise')
            d[v]=winsorize_series(d[v])
    for v in BINARY:
        d[v]=pd.to_numeric(d[v],errors='raise')
        if (d[v].notna() & ~d[v].isin([0,1])).any():
            raise ValueError(f'{v} must be coded 0/1; unknown is NaN, not 0')
    if d[MAIN_FIELDS].isna().any(axis=None):
        n=d[MAIN_FIELDS].isna().any(axis=1).sum()
        raise ValueError(f'{n} firm-years lack required fields. Do not silently modify the reported analysis sample.')
    if ((d['RDINT']<0)).any():
        raise ValueError('Negative RDINT requires source review')
    rd_sd=d.RDINT.std(ddof=1)
    if not np.isfinite(rd_sd) or rd_sd==0: raise ValueError('R&D intensity has zero/undefined SD')
    d['RDINT_Z']=(d.RDINT-d.RDINT.mean())/rd_sd
    d['SINGLE_X_RDINT']=d.SINGLE*d.RDINT_Z
    d['PHD_X_RDINT']=d.PHD*d.RDINT_Z
    return d

def fe_formula(outcome, interactions=False,extra_terms=None,firm_trends=False):
    terms=EXECUTIVE+['RDINT_Z']+CONTROLS
    if interactions: terms+=['SINGLE_X_RDINT','PHD_X_RDINT']
    if extra_terms: terms+=list(extra_terms)
    terms+=['C(firm_id)','C(year)']
    if firm_trends: terms+=['C(firm_id):year_centered']
    return outcome+' ~ '+' + '.join(terms)

def fit_fe(df,outcome,interactions=False,extra_terms=None,firm_trends=False):
    d=df.copy()
    if firm_trends: d['year_centered']=d.year-d.year.mean()
    model=smf.ols(fe_formula(outcome,interactions,extra_terms,firm_trends),data=d,missing='drop')
    group=d.loc[model.data.row_labels,'firm_id']
    if group.nunique()<2: raise ValueError('Need at least 2 firm clusters')
    return model.fit(cov_type='cluster',cov_kwds={'groups':group})

def tidy_model(model, keep=None):
    rows=[]
    for term,coef in model.params.items():
        if keep is not None and term not in keep:continue
        rows.append({'term':term,'coef':float(coef),'std_err':float(model.bse[term]),
          't':float(model.tvalues[term]),'p':float(model.pvalues[term]),
          'nobs':int(model.nobs),'adj_r2':float(model.rsquared_adj)})
    return pd.DataFrame(rows)
