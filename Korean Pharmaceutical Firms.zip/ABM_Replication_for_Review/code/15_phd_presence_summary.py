"""Descriptive audit of author-coded ANY-representative doctorate by SINGLE status.

Does not infer person identities; uses only original source-checked binary codes.
"""
import pandas as pd
from common import DATA, OUT, require_columns

D = pd.read_csv(DATA/'analysis_panel_raw.csv', dtype={'firm_id': str})
require_columns(D,['firm_id','year','SINGLE','PHD'])
if D.duplicated(['firm_id','year']).any():
    raise ValueError('Duplicate firm-year in coding audit')
if D[['SINGLE','PHD']].isna().any().any() or not D.SINGLE.isin([0,1]).all() or not D.PHD.isin([0,1]).all():
    raise ValueError('SINGLE and PHD must be nonmissing binary variables')
rows=[]
for single,label in [(1,'single_registered_representative'),(0,'multiple_registered_representatives')]:
    sub = D[D.SINGLE==single]
    n1=int((sub.PHD==1).sum());n0=int((sub.PHD==0).sum())
    rows.append({'SINGLE':single,'structure':label,'n_firmyears':len(sub),
                 'PHD_1_any_representative':n1,'PHD_0_none':n0,
                 'PHD_1_share':n1/len(sub)})
rows.append({'SINGLE':'all','structure':'all','n_firmyears':len(D),
             'PHD_1_any_representative':int((D.PHD==1).sum()),
             'PHD_0_none':int((D.PHD==0).sum()),
             'PHD_1_share':D.PHD.mean()})
result=pd.DataFrame(rows)
result.to_csv(OUT/'phd_presence_by_structure.csv',index=False)
print(result.to_string(index=False))
