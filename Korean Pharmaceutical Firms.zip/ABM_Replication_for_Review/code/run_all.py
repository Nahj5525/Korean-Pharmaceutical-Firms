"""Reproduction entrypoint: required input absence is a hard, visible stop."""
import argparse,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--with-bootstrap',action='store_true',help='Optional 9,999 firm wild cluster draws')
parser.add_argument('--with-prediction',action='store_true',help='Optional strictly forward predictive checks')
parser.add_argument('--with-shap',action='store_true',help='Optional SHAP on locked holdout')
parser.add_argument('--duplicate-policy',choices=['error','average_rd','first','last'],default='error')
args=parser.parse_args()
required=ROOT/'data'/'analysis_panel_raw.csv'
if not required.exists():
    print('\nREPRODUCTION NOT STARTED: authorized 723-row firm-year source panel is absent.')
    print('Snapshots in documented_results are transcriptions of supplied tables, not computed results.')
    print('See README_KR.md and schemas. No synthetic study data have been substituted.')
    raise SystemExit(2)
def go(name,*flags):
    task=ROOT/'code'/name
    print('\n=== RUN',task.name,'===',flush=True)
    cp=subprocess.run([sys.executable,str(task),*flags],cwd=ROOT)
    if cp.returncode!=0:raise SystemExit(f'STOP: {name} failed (exit {cp.returncode}); no later stage is valid')
if (ROOT/'data'/'included_source_725_rows.csv').exists():go('00_audit_725_to_723.py')
go('01_prepare_analysis_panel.py','--duplicate-policy',args.duplicate_policy)
go('15_phd_presence_summary.py')
go('02_main_models.py')
go('03_robustness.py')
go('13_multiple_testing.py')
go('09_result_snapshot_check.py')
# Verified new empirical extensions based on the preserved 723-row numeric panel.
go('16_outcome_contrast_tests.py')
go('17_timing_and_rd_robustness.py')
go('18_secondary_crosswalk_adjudication.py')
go('19_annual_transition_windows.py')
if args.with_bootstrap:go('10_wild_cluster_bootstrap.py')
if (ROOT/'data'/'director_crosswalk.csv').exists():go('11_director_crosswalk_audit.py')
# Text-only extensions were removed from the revised article: source sentences and
# independent human ratings were not supplied. Optional scripts remain archived for
# input-dependent historical checking, not as submission findings.
if args.with_prediction or args.with_shap:
    go('07_predictive_validation.py')
    go('14_locked_holdout_shap.py',*(['--shap'] if args.with_shap else []))
# Do not silently run older text/validation routines or report their outputs.
if {'RD_EXP','SALES'}.issubset(set(__import__('pandas').read_csv(required,nrows=0).columns)):
    go('12_alternative_rd_denominator.py')
go('08_figure1.py')
print('\nUpgraded accounting/valuation contrast and temporal model stages completed.')
print('R&D/sales remains NOT TESTED without original R&D expense and sales amounts.')
print('Original text/rater extension EXCLUDED from submission claims (no raw inputs).')
