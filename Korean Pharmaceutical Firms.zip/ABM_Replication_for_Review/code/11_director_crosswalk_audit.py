"""Compare the author's ANY-registered-representative PhD coding with a roster (OPTIONAL).

PHD=1 if ONE documented registered representative holds an awarded PhD.
PHD=0 requires a complete registered-representative roster with every status known
and no doctorate. If the roster is incomplete but a PhD holder is known, status 1
can still be identified; unknown holders must never be coerced to 0.
"""
import pandas as pd
from common import DATA,OUT,require_columns
src=DATA/'director_crosswalk.csv'
if not src.exists():raise SystemExit('No director_crosswalk.csv: optional independent roster audit unavailable; historical PHD rule is documented in README.')
col=['firm_id','year','director_id','registered_representative','phd_verified','census_complete','source_filing_id','filing_date']
d=pd.read_csv(src,dtype={'firm_id':str,'director_id':str,'source_filing_id':str})
require_columns(d,col)
if d.duplicated(['firm_id','year','director_id']).any():raise ValueError('duplicate director/firm/year rows')
for x in ['registered_representative','census_complete']:
    if (~d[x].isin([0,1])).any():raise ValueError('Malformed '+x)
if (~(d['phd_verified'].isna()|d['phd_verified'].isin([0,1]))).any():raise ValueError('phd_verified must be 0,1 or NA')
# Verify that a complete census claim is uniform for all records in a firm-year.
if d.groupby(['firm_id','year'])['census_complete'].nunique().gt(1).any():
    raise ValueError('census_complete cannot differ within one firm-year')
rows=[]
for (fid,y),g in d.groupby(['firm_id','year']):
    reps=g[g.registered_representative==1]
    complete=bool(g.census_complete.iloc[0])
    if complete and len(reps)==0:raise ValueError(f'Complete census but zero registered reps: {fid}, {y}')
    # One confirmed doctoral representative is enough to establish 1, even if the
    # roster is incomplete. Zero requires the ENTIRE representative roster checked.
    status = pd.NA
    if len(reps)>0 and reps.phd_verified.eq(1).any():
        status = 1
    elif complete and len(reps)>0 and reps.phd_verified.notna().all():
        status = 0
    rows.append({'firm_id':fid,'year':y,'registered_reps_count':len(reps),
                 'verified_any_representative_phd':status,'complete_census':complete,
                 'joint_signature_verified':g['joint_signature_registered'].iloc[0] if 'joint_signature_registered' in g and g['joint_signature_registered'].nunique(dropna=False)==1 else pd.NA,
                 'source_filing_count':g.source_filing_id.nunique()})
verify=pd.DataFrame(rows)
raw=DATA/'analysis_panel_raw.csv'
if raw.exists():
    panel=pd.read_csv(raw,dtype={'firm_id':str})[['firm_id','year','PHD','SINGLE']].drop_duplicates(['firm_id','year'])
    verify=verify.merge(panel,on=['firm_id','year'],how='outer',validate='one_to_one',indicator='crosswalk_merge')
    # Comparison is meaningful only when both archival and roster codes exist.
    valid=verify.PHD.notna() & verify.verified_any_representative_phd.notna()
    verify['archival_vs_verified_disagrees']=pd.Series(pd.NA,index=verify.index,dtype='boolean')
    verify.loc[valid,'archival_vs_verified_disagrees']=(
        verify.loc[valid,'PHD'].astype(int).ne(
        verify.loc[valid,'verified_any_representative_phd'].astype(int))).to_numpy()
    valid_count=verify.registered_reps_count.notna() & verify.SINGLE.notna() & verify.complete_census.eq(True)
    verify['registered_count_matches_SINGLE']=pd.Series(pd.NA,index=verify.index,dtype='boolean')
    verify.loc[valid_count,'registered_count_matches_SINGLE']=(
        verify.loc[valid_count,'registered_reps_count'].eq(1).eq(
        verify.loc[valid_count,'SINGLE'].eq(1))).to_numpy()
verify.to_csv(OUT/'director_crosswalk_audit.csv',index=False)
print('Crosswalk audit written. An unknown degree remains NA, never automatically 0.')
