"""OPTIONAL 2023–2024 locked holdout and tree SHAP, only from authorized data.

Model tuning uses target year 2022; all fitted outcomes have target year <=2022.
2023–24 are never used for hyperparameter choice or fitting. Output is optional,
not claimed as an available finding in the revised manuscript.
"""
import argparse
import numpy as np
import pandas as pd
from pathlib import Path
from common import OUT
from importlib.machinery import SourceFileLoader
from importlib.util import spec_from_loader,module_from_spec
path=Path(__file__).with_name('07_predictive_validation.py')
loader=SourceFileLoader('strict_prediction',str(path));spec=spec_from_loader(loader.name,loader)
pred=module_from_spec(spec);loader.exec_module(pred)

parser=argparse.ArgumentParser()
parser.add_argument('--shap',action='store_true',help='Compute mean absolute tree SHAP only if shap is installed and applicable')
args=parser.parse_args()

d=pred.load_strict_panel();rows=[];shap_rows=[]
for y in ['ROA','TQ']:
  for cohort,frame,sets in pred.cohort_sets(d,y):
    train=frame[frame.target_year<=2021];val=frame[frame.target_year==2022]
    refit=frame[frame.target_year<=2022];test=frame[frame.target_year.isin([2023,2024])]
    if min(len(train),len(val),len(refit),len(test))<5:continue
    for fs,cols in sets.items():
      for modelname,(base,grid) in pred.models().items():
        params=pred.tuning_fit(train,val,cols,y,base,grid)
        if params is None:continue
        pipe=pred.estimator(base,params).fit(refit[cols],refit['TARGET_'+y])
        forecast=pipe.predict(test[cols])
        for firm,year,actual,yhat in zip(test.firm_id,test.target_year,test['TARGET_'+y],forecast):
          rows.append({'cohort':cohort,'outcome':y,'firm_id':firm,'target_year':year,
             'feature_set':fs,'model':modelname,'actual':float(actual),'prediction':float(yhat),
             'model_train_max_target_year':2022,'params_selected_on_target_year':2022})
        if args.shap and modelname in ['RandomForest','XGBoost']:
          import shap
          processed=pipe[:-1].transform(test[cols])
          explainer=shap.TreeExplainer(pipe.named_steps['model'])
          shap_values=explainer.shap_values(processed)
          arr=np.asarray(shap_values)
          if arr.ndim!=2:raise ValueError('Unexpected SHAP output shape; do not publish values')
          importance=np.abs(arr).mean(axis=0)
          for feature,val in zip(cols,importance):
            shap_rows.append({'cohort':cohort,'outcome':y,'feature_set':fs,
                'model':modelname,'feature':feature,'mean_abs_SHAP':float(val),
                'holdout_years':'2023-2024'})
if not rows:raise SystemExit('No sample-valid locked holdout estimates can be made')
pd.DataFrame(rows).to_csv(OUT/'locked_2023_2024_predictions.csv',index=False)
if shap_rows:pd.DataFrame(shap_rows).to_csv(OUT/'locked_holdout_shap_mean_abs.csv',index=False)
print('Completed locked, strictly forward models; NO result is presumed significant')
