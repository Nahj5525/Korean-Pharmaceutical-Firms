"""Within-firm and construct-validity diagnostics; none implies causality."""
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from common import OUT,CONTROLS,EXECUTIVE,fit_fe
src=OUT/'analysis_panel_prepared.csv'
if not src.exists():raise SystemExit('Prepare authorized panel first')
df=pd.read_csv(src,dtype={'firm_id':str}).sort_values(['firm_id','year']).reset_index(drop=True)
focus={
 'SINGLE_ROA':('ROA','SINGLE',True),'SINGLE_ROE':('ROE','SINGLE',True),
 'PHD_TQ':('TQ','PHD',True),'PHDxRD_TQ':('TQ','PHD_X_RDINT',True),
 'PHD_MB':('MB','PHD',True),'PHDxRD_MB':('MB','PHD_X_RDINT',True)}
rows=[]
def collect(label,design,m,term):
    if term not in m.params:raise ValueError(f'No {term} term for {label} / {design}')
    rows.append({'relationship':label,'design':design,'term':term,
      'coef':float(m.params[term]),'t':float(m.tvalues[term]),'p':float(m.pvalues[term]),
      'nobs':int(m.nobs),'n_firms':int(nfirms)})

def clustered(formula,d):
    base=smf.ols(formula,d,missing='drop')
    groups=d.loc[base.data.row_labels,'firm_id']
    global nfirms
    nfirms=groups.nunique()
    return base.fit(cov_type='cluster',cov_kwds={'groups':groups})

for label,(y,term,inter) in focus.items():
    nfirms=df.firm_id.nunique();collect(label,'baseline_fe',fit_fe(df,y,interactions=inter),term)
    focal='SINGLE' if term=='SINGLE' else 'PHD'
    sw=df.groupby('firm_id')[focal].nunique(dropna=True)
    sub=df[df.firm_id.isin(sw[sw>1].index)]
    nfirms=sub.firm_id.nunique();collect(label,'switcher_only_fe',fit_fe(sub,y,interactions=inter),term)
    nfirms=df.firm_id.nunique();collect(label,'firm_specific_trend',fit_fe(df,y,interactions=inter,firm_trends=True),term)

# First differences on adjacent years only, including delta of interaction itself.
base_vars=list(dict.fromkeys(EXECUTIVE+['RDINT_Z','SINGLE_X_RDINT','PHD_X_RDINT']+CONTROLS+['ROA','ROE','TQ','MB']))
g=df.groupby('firm_id',sort=False)
fd=df[['firm_id','year']].copy()
for c in base_vars:fd['D_'+c]=g[c].diff()
fd=fd[g.year.diff().eq(1)].copy()
for label,(y,term,inter) in focus.items():
    terms=['D_'+x for x in EXECUTIVE+['RDINT_Z']+CONTROLS]
    if inter:terms+=['D_SINGLE_X_RDINT','D_PHD_X_RDINT']
    m=clustered('D_'+y+' ~ '+' + '.join(terms)+' + C(year)',fd)
    collect(label,'first_difference',m,'D_'+term)

for label,(y,term,inter) in focus.items():
    sub=df[~df.year.isin([2020,2021])];nfirms=sub.firm_id.nunique()
    collect(label,'exclude_2020_2021',fit_fe(sub,y,interactions=inter),term)

# Log R&D scale; alternative *functional form*, not alternative denominator.
dlog=df.copy()
dlog['LOG_RD_Z']=np.log1p(dlog.RDINT.clip(lower=0))
dlog['LOG_RD_Z']=(dlog.LOG_RD_Z-dlog.LOG_RD_Z.mean())/dlog.LOG_RD_Z.std(ddof=1)
dlog['SINGLE_X_LOGRD']=dlog.SINGLE*dlog.LOG_RD_Z
dlog['PHD_X_LOGRD']=dlog.PHD*dlog.LOG_RD_Z
for y in ['TQ','MB']:
    f=y+' ~ SINGLE + PHD + BUS + LONGTEN + LOG_RD_Z + SINGLE_X_LOGRD + PHD_X_LOGRD + '+' + '.join(CONTROLS)+' + C(firm_id) + C(year)'
    m=clustered(f,dlog);collect('PHDxRD_'+y,'log_rd',m,'PHD_X_LOGRD')

# Subsamples should exclude constant SINGLE and its R&D interaction.
for name,sub in [('single_rep_only',df[df.SINGLE==1]),('multiple_rep_only',df[df.SINGLE==0])]:
    for y in ['TQ','MB']:
        f=y+' ~ PHD + BUS + LONGTEN + RDINT_Z + PHD_X_RDINT + '+' + '.join(CONTROLS)+' + C(firm_id) + C(year)'
        m=clustered(f,sub)
        for term in ['PHD','PHD_X_RDINT']:
            collect(term+'_'+y,name,m,term)
# Formal interactions, not a comparison of significance decisions.
for y in ['TQ','MB']:
    f=y+' ~ PHD*SINGLE*RDINT_Z + BUS + LONGTEN + '+' + '.join(CONTROLS)+' + C(firm_id) + C(year)'
    m=clustered(f,df)
    for term in ['PHD:SINGLE','PHD:SINGLE:RDINT_Z']:
        collect(term+'_'+y,'formal_heterogeneity',m,term)

# Reverse selection: ensure the previous calendar year is available.
for focal,outcome in [('SINGLE','ROA'),('PHD','TQ')]:
    d=df.copy();g=d.groupby('firm_id',sort=False)
    consecutive=g.year.diff().eq(1)
    lag_vars=[outcome]+CONTROLS
    for c in lag_vars:
        d['L1_'+c]=g[c].shift(1).where(consecutive)
    f=focal+' ~ L1_'+outcome+' + '+' + '.join('L1_'+c for c in CONTROLS)+' + C(firm_id) + C(year)'
    m=clustered(f,d);collect('lagged_'+outcome+'_to_'+focal,'reverse_selection',m,'L1_'+outcome)

for focal,y in [('SINGLE','ROA'),('SINGLE','ROE'),('PHD','TQ'),('PHD','MB')]:
    d=df.copy();g=d.groupby('firm_id',sort=False)
    d['F1_'+focal]=g[focal].shift(-1).where(g.year.shift(-1).eq(d.year+1))
    m=fit_fe(d,y,interactions=(focal=='PHD'),extra_terms=['F1_'+focal])
    # compute used clusters for this model (not entire sample)
    nfirms=d.loc[m.model.data.row_labels,'firm_id'].nunique()
    collect('future_'+focal+'_'+y,'future_status_placebo',m,'F1_'+focal)

pd.DataFrame(rows).to_csv(OUT/'robustness_models.csv',index=False)
print('Wrote',len(rows),'reported+new robustness diagnostics; results require real panel')
