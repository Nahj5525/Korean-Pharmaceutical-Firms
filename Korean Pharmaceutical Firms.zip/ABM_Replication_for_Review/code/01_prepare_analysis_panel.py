"""Make a source-linked firm-year panel, with explicit duplicate reconciliation.

Never silently average discrepant observations. Historical report averaged RDINT in two
conflicting duplicate pairs; --duplicate-policy average_rd reproduces that *choice*
only after logging both candidates. The default 'error' demands verification.
"""
from pathlib import Path
import argparse
import pandas as pd
from common import DATA, OUT, prepare_panel, require_columns

parser=argparse.ArgumentParser()
parser.add_argument('--duplicate-policy',choices=['error','average_rd','first','last'],default='error')
args=parser.parse_args()
src=DATA/'analysis_panel_raw.csv'
if not src.exists():
    raise SystemExit(f'Missing {src}. See README_KR.md; no study microdata were distributed.')
df=pd.read_csv(src, dtype={'firm_id':str, 'stock_code':str}, low_memory=False)
require_columns(df,['firm_id','year','RDINT'])
df['year']=pd.to_numeric(df.year,errors='raise').astype(int)
if df[['firm_id','year']].isna().any().any():
    raise SystemExit('Missing firm/year keys are not permitted.')
keys=['firm_id','year']
if df.duplicated(keys).any():
    dup=df[df.duplicated(keys,keep=False)].sort_values(keys)
    dup.to_csv(OUT/'duplicate_firm_years_detected.csv',index=False)
    if args.duplicate_policy=='error':
        raise SystemExit('Conflicting or repeated firm-year keys. See outputs/duplicate_firm_years_detected.csv; reconcile with filings or explicitly choose policy.')
    if args.duplicate_policy=='average_rd':
        # Require other fields to be identical; tolerate missing consistently only.
        fields=[c for c in df.columns if c not in keys+['RDINT']]
        for _,block in dup.groupby(keys,sort=False):
            for name in fields:
                if block[name].nunique(dropna=False)!=1:
                    raise SystemExit(f'Conflicting duplicate non-RDINT field {name}; cannot use average_rd')
        meanrd=df.groupby(keys,sort=False)['RDINT'].transform('mean')
        df['RDINT']=meanrd
        df=df.drop_duplicates(keys,keep='first')
    elif args.duplicate_policy in ('first','last'):
        df=df.drop_duplicates(keys,keep=args.duplicate_policy)
    pd.DataFrame([{'source_file':src.name,'duplicate_policy':args.duplicate_policy,
                   'duplicate_rows':len(dup),'unique_conflicts':dup[keys].drop_duplicates().shape[0]}]).to_csv(
                  OUT/'duplicate_resolution_log.csv',index=False)
prepared=prepare_panel(df)
prepared.to_csv(OUT/'analysis_panel_prepared.csv',index=False)
print('Prepared',len(prepared),'firm-years in',prepared.firm_id.nunique(),'firms; duplicate policy',args.duplicate_policy)
if len(prepared)!=723 or prepared.firm_id.nunique()!=87:
    print('WARNING: Counts differ from reported 723 rows/87 firms. Resolve rather than forcing a match.')
