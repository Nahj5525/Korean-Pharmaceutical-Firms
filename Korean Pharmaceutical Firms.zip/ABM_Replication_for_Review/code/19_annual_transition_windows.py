"""Descriptive surrounding-year windows for observed annual binary status changes.

Not an event-study causal estimate: exact intra-year filing/appointment dates,
parallel trends, and counterfactual comparison groups are not identified.
Only distinct, locally isolated annual status transitions with consecutive
records over t-2 ... t+1 are retained; firm-years may contribute more than once
across well-separated episodes, so no inferential p-values are provided.
"""
import pandas as pd
import numpy as np
from common import OUT

d=pd.read_csv(OUT/'analysis_panel_prepared.csv',dtype={'firm_id':str}).sort_values(['firm_id','year']).reset_index(drop=True)
rows=[]
for f,g in d.groupby('firm_id'):
    g=g.set_index('year').sort_index()
    for x,y in [('SINGLE','ROA'),('SINGLE','ROE'),('PHD','TQ'),('PHD','MB')]:
        series=g[x].to_dict()
        transitions=[t for t in g.index if t-1 in g.index and series[t]!=series[t-1]]
        for t in transitions:
            if not all(k in g.index for k in [t-2,t-1,t,t+1]):continue
            # Exclude overlapping annual toggles in the local window.
            if any(z in transitions for z in [t-1,t+1]):continue
            old,new=int(series[t-1]),int(series[t]); sign=1 if new==1 else -1
            pre=float(g.loc[t-1,y]-g.loc[t-2,y])
            event=float(g.loc[t,y]-g.loc[t-1,y])
            post=float(g.loc[t+1,y]-g.loc[t,y])
            rows.append(dict(firm_id=f,event_year=int(t),focal=x,outcome=y,direction='0_to_1' if sign==1 else '1_to_0',
                pre_change=pre,event_change=event,post_change=post,
                entry_equivalent_pre=sign*pre,entry_equivalent_event=sign*event,entry_equivalent_post=sign*post))
out=pd.DataFrame(rows)
out.to_csv(OUT/'isolated_annual_transition_windows.csv',index=False)
if len(out):
    agg=out.groupby(['focal','outcome','direction']).agg(episodes=('firm_id','size'),firms=('firm_id','nunique'),
        mean_pre=('pre_change','mean'),mean_event=('event_change','mean'),mean_post=('post_change','mean'))
    agg.reset_index().to_csv(OUT/'isolated_transition_descriptive_summary.csv',index=False)
    print(agg.round(4).to_string())
else:
    print('No consecutive isolated windows available; no numeric transition claims.')
print('WARNING: Descriptive, not a dated event study. No causal p-values inferred.')
