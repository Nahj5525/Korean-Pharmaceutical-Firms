"""Holm stepdown for the six prespecified core hypothesis/outcome tests."""
import pandas as pd
from statsmodels.stats.multitest import multipletests
from common import OUT
src=OUT/'main_models.csv'
if not src.exists():raise SystemExit('Main empirical models not yet available')
d=pd.read_csv(src)
plan=[('H1','ROA','main','SINGLE'),('H1','ROE','main','SINGLE'),
      ('H2','TQ','main','PHD'),('H2','MB','main','PHD'),
      ('H3','TQ','interaction','PHD_X_RDINT'),('H3','MB','interaction','PHD_X_RDINT')]
rows=[]
for hyp,y,spec,term in plan:
    match=d[(d.outcome==y)&(d.spec==spec)&(d.term==term)]
    if len(match)!=1:raise ValueError(f'Missing {hyp}/{y}/{spec}/{term}')
    rows.append({'hypothesis':hyp,'outcome':y,'spec':spec,'term':term,'p_nominal':float(match.iloc[0].p)})
res=pd.DataFrame(rows)
res['p_holm_family6']=multipletests(res.p_nominal,method='holm')[1]
res['reject_Holm_05']=res.p_holm_family6<0.05
res.to_csv(OUT/'focal_hypotheses_holm.csv',index=False)
print(res.to_string(index=False))
