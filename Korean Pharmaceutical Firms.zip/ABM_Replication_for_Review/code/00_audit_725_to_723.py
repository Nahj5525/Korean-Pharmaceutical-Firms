"""Reconcile the included 725 historical rows into 723 unique firm-years.

The old author-held workbook averaged R&D intensity for two conflicting pairs.
This script faithfully *audits* that historical decision and compares its result
with the distributed 723-row panel. It does NOT claim the arithmetic average is
the filing-authoritative value. It never overwrites the primary input.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from common import DATA,OUT
src=DATA/'included_source_725_rows.csv'
if not src.exists():raise SystemExit('Included 725-row source extract is absent')
r=pd.read_csv(src,dtype={'firm_id':str})
rename={'R&D':'RDINT','big4':'BIG4','forn':'FORN','largest':'LARGEST','CEO':'SINGLE',
        'EDU':'PHD','major':'BUS','tenure':'LONGTEN'}
r=r.rename(columns=rename)
vars=['ROA','ROE','TQ','MB','SINGLE','PHD','BUS','LONGTEN','RDINT','SIZE','LEV',
      'CUR','GRW','CFO','AGE','FORN','LARGEST','BIG4','LOSS']
for col in ['firm_id','year','source_row']+vars:
 if col not in r:raise ValueError('Missing included source item '+col)
key=['firm_id','year'];dup=r[r.duplicated(key,keep=False)]
if len(dup)!=4 or dup[key].drop_duplicates().shape[0]!=2:
 raise ValueError('Expected two historical duplicated firm-year pairs, no more')
for _,g in dup.groupby(key,sort=False):
 for col in [x for x in vars if x!='RDINT']:
  if g[col].nunique(dropna=False)!=1:raise ValueError('Unexpected duplicate conflict '+col)
    
r['dupflag']=r.duplicated(key,keep=False).astype(int)
agg=r.groupby(key,sort=False)['RDINT'].transform('mean')
r['RDINT']=agg
r['source_rows']=r.groupby(key,sort=False).source_row.transform(lambda s:';'.join(map(str,sorted(s))))
r['duplicate_resolved']=r.dupflag
r=r.drop_duplicates(key,keep='first').sort_values(key)
expected=pd.read_csv(DATA/'analysis_panel_raw.csv',dtype={'firm_id':str})
reconciled=r[key+vars+['duplicate_resolved']].merge(expected[key+vars+['duplicate_resolved']],on=key,
   how='outer',indicator=True,validate='one_to_one',suffixes=('_reconstructed','_preserved'))
if (reconciled['_merge']!='both').any():raise ValueError('735/723 identity mismatch')
rows=[]
for v in vars+['duplicate_resolved']:
  a=pd.to_numeric(reconciled[v+'_reconstructed'],errors='raise')
  b=pd.to_numeric(reconciled[v+'_preserved'],errors='raise')
  err=float(np.nanmax(np.abs(a-b)))
  rows.append({'variable':v,'max_abs_diff':err,'match_tol1e10':bool(err<1e-10)})
report=pd.DataFrame(rows)
report.to_csv(OUT/'included725_to_clean723_check.csv',index=False)
print('Included-source audit: 725 ->',len(r),'rows; 2 R&D duplicate pairs averaged, not source-authority adjudicated')
print('All historical values match retained panel:',report.match_tol1e10.all())
if not report.match_tol1e10.all():raise SystemExit('FAIL: included rows do not reconcile with 723 retained panel')
