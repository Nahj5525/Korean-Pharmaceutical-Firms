import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from common import OUT, fit_fe

src=OUT/"analysis_panel_prepared.csv"
if not src.exists(): raise SystemExit("Run 01_prepare_analysis_panel.py first")
df=pd.read_csv(src)
m=fit_fe(df,"TQ",interactions=True)
b1=m.params["PHD"]; b2=m.params["PHD_X_RDINT"]
cov=m.cov_params()
raw=np.linspace(max(0,df.RDINT.min()),min(df.RDINT.max(),df.RDINT.quantile(.99)),120)
mu=df.RDINT.mean(); sd=df.RDINT.std(ddof=1); z=(raw-mu)/sd
eff=b1+b2*z
var=cov.loc["PHD","PHD"] + z*z*cov.loc["PHD_X_RDINT","PHD_X_RDINT"] + 2*z*cov.loc["PHD","PHD_X_RDINT"]
se=np.sqrt(np.maximum(var,0)); lo=eff-1.96*se; hi=eff+1.96*se
fig,ax=plt.subplots(figsize=(7,4.5))
ax.plot(raw*100,eff,linestyle='-',color='0.25',label='Estimated marginal effect')
ax.fill_between(raw*100,lo,hi,color='0.85',label='95% confidence interval')
ax.axhline(0,linestyle='--',linewidth=1,color='0.35')
med=df.RDINT.median()*100; ax.axvline(med,linestyle=':',linewidth=1,color='0.35')
ax.set_xlabel('R&D expenditure / total assets (%)'); ax.set_ylabel("Marginal effect on Tobin's Q")
ax.legend(frameon=False); fig.tight_layout(); fig.savefig(OUT/"figure1_reproduced.png",dpi=600,bbox_inches='tight')
print("Wrote outputs/figure1_reproduced.png")
