# Empirical input lineage and responsible sharing

**Present files (actual previously archived author-derived observations):**
- `analysis_panel_raw.csv`: 723 cleaned firm-years, 87 firms, numeric variables before winsorization and R&D standardization. Based on `Clean_723` in `CEO_Pharmaceutical_Replication_Dataset.xlsx` retained in the author-side research archive. Firm names and stock codes are stripped and `firm_id` is a stable anonymized 1–87 numeric identifier.
- `included_source_725_rows.csv`: 725 included pre-dedup source rows, based on the same author's workbook `Raw_725`; the numeric stock-to-panel mapping is replaced with anonymized `firm_id`. Code `00_audit_725_to_723.py` checks the two R&D disagreements and the arithmetic average against the preserved 723-row panel.

**Absent source records:** the original 1,209-row preselection universe, direct TS-2000 licensed downloads, **the source-by-source ledger from the authors' reported manual DART review**, human-rating records, source sentences, and actual R&D expenditure and sales amounts. These items are essential for fully validating source selection, construct validity, classifier metrics, and alternative denominators.

`director_crosswalk_TEMPLATE.csv`, `sentence_archive_TEMPLATE.csv`, and `validation_ratings_TEMPLATE.csv` have column names only: they are NOT observation data.

The authors report personally checking executive-representative and PhD coding against the companies' business reports. They further confirmed that **PHD=1 if any one registered representative director holds a doctoral degree** in a multi-representative firm, and 0 if none holds one; the source panel remains unaltered. The separate `audit/opendart_partial_qa_firmyears.csv` retains the **auxiliary crosswalk's own** comparison statuses: 18 entries compared and 705 absent from that supplementary workflow. The 7 SINGLE and 11 PHD flags were calculated using the crosswalk's separately assembled roster and any-degree fields and have not been adjudicated against matched eligibility rosters, report dates and degree evidence, despite the now-matching any-member PHD threshold. They cannot be labeled as proven archival input errors or as evidence that the authors did not manually check the 705 additional entries.

**Legal note:** the user-provided derived data may be analyzed internally, but public redistribution may require authorization under the upstream TS-2000 agreement. This zip should not be uploaded unchanged to a public repository without reviewing those rights and any confidentiality constraints.
