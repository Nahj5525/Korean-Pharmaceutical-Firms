# R&D scaled by sales: not yet computable from preserved panel

The preserved 723-row panel contains `RDINT = R&D/assets` and SIZE (log of
beginning total assets). It does **NOT** contain auditable standalone RD_EXP
(R&D expense) and SALES at the same accounting scope and fiscal year.

The `RD_EXP_SALES_SOURCE_REQUEST_TEMPLATE.csv` documents the *required* items.
Fill source accounting amounts with their corresponding annual filings and the
same units/scope. Do not infer the amounts from the R&D/assets ratio and SIZE:
the numerator may have differing accounting definitions and periods, and SIZE
is beginning assets. Once the real amounts are joined to `analysis_panel_raw.csv`
by unique firm-year, `code/12_alternative_rd_denominator.py` computes the
R&D/sales sensitivity. This analysis has NOT been performed in the current
article. Year-(t-1) RDINT and the MB outcome are partial, not full substitutes.
