# Programmatically generated outputs

`analysis_panel_prepared.csv`: prepared 723-row data (author-code preservations).
`main_models.csv`, `robustness_models.csv`, `focal_hypotheses_holm.csv`, `snapshot_check.csv`: recreated historical regressions and checks.
`direct_outcome_contrasts_primary_six.csv`: new Table 6, six paired SD-standardized comparisons with independent Holm.
`direct_outcome_contrasts_full.csv`: additional exploratory pairings, not focal hypothesis family.
`timing_rd_sensitivity.csv`: new Table 8 source, every estimated temporal, alternative-denominator, reverse-status check (635 panels where lag required).
`isolated_annual_transition_windows.csv`, `isolated_transition_descriptive_summary.csv`: yearly recoding windows without causal p-values.
`secondary_18_case_reconciliation_template.csv`: prepopulated 18-case filing comparison checklist, all nonconcordance **unadjudicated**.
`figure1_reproduced.png`: existing conditional estimated PHD valuation graph.
No output here is a real R&D/sales estimate or verified NLP text/ratings result.
