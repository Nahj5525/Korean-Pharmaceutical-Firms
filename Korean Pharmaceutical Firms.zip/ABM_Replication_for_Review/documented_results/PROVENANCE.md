# Result provenance after ABM upgrade (2026-10-11)

- Historical Table 1-5 and Table 7 CSV snapshots are transcribed from prior author reports and have their numerical modeling counterparts in `outputs/`. They are not new claims.
- `table6_direct_outcome_contrasts_RECOMPUTED.csv` is generated from `code/16_outcome_contrast_tests.py` and is the **NEW** Table 6.
- `table8_temporal_rd_robustness_RECOMPUTED.csv` is generated from `code/17_timing_and_rd_robustness.py`; the manuscript Table 8 is an eight-row selection of this full table.
- `table9_focal_holm_RECOMPUTED.csv` is generated from `code/13_multiple_testing.py`; the manuscript Table 9 is the prior Table 8 (renumbered).
- An earlier report-text extension was excluded from the submitted manuscript and from this reviewer archive: its original sentence corpus and human ratings are unavailable.
- The 18-case independent filing QA table is not the author's original manual verification. No author-coded SINGLE/PHD values were changed.
- The genuine R&D expenditure / sales ratio cannot be calculated from this version's inputs.
