# Author manual verification vs. auxiliary automatic crosswalk

## What the author explicitly confirmed

On 10 October 2026 the author stated that the representative-director and doctoral-education variables had been checked **individually against the companies' business reports**. On 11 October 2026 the author specified **PHD = 1 if at least one registered representative director has a doctoral degree, including one member of a multi-representative roster; PHD = 0 if none does.** The manuscript therefore describes the original collection as an author-performed manual review of DART disclosures. This direct author statement is not an independently conducted or notarized verification in the current package.

## Clarified PHD rule and the separate 18/705 comparison

The `opendart_partial_qa_firmyears.csv` file is a **separate comparison dataset**, not a full record of what the authors checked during original data construction. Its `VERIFIED` (18) and `PENDING_SOURCE` (705) statuses refer to that alternate secondary comparison. Describing 705 as *unverified by the authors* incorrectly equates the two workflows.

Within the 18 observations, 7 historical SINGLE codes differ from `SINGLE_corrected`, where the latter is derived from the alternate roster count. Eleven PHD codes differ from `ANY_PHD`, which also identifies **any** representative with a doctoral degree. **The any-member threshold is now confirmed to match** across PHD and ANY_PHD, so this particular definitional difference no longer explains the discrepancies. They are real differences between preserved tables, but cannot be labeled **proven errors** until firm-year mapping, dates, roster inclusion and doctorate documentation match.

## Definitions to align before adjudication

1. Same company identifiers, fiscal year and effective date (e.g. as of 31 December versus annual tenure during the year).
2. Same population: registered representative directors, active CEOs, board members, or all people who represented the company during the year.
3. Same representative rule: single versus multiple registered representatives; joint-signature authority is a separate legal question.
4. Same education rule: **the any-representative threshold is confirmed for the author-coded PHD**. Confirm which persons are registered representatives at the reference date, documentary evidence of a *held* doctoral degree (rather than candidacy/coursework), and original source filing.
5. Same handling of appointments, resignations, restatements and amended business reports.

Until such alignment is documented, preserve original author-coded values in all regressions, label the 18 as **definition-unadjudicated secondary comparison flags**, and do not assign an error rate to the other 705 observations.

## Remaining reproducibility limits independent of manual source checking

- The identifier-minimized numeric panel and FE/Holm result reproduction **are available**.
- The original filing-by-filing audit ledger and submitted-source extracts are **not provided** in this package; this is a traceability limit, not proof that manual checking did not occur.
- Full original text corpus, human-rating matrix and the two conflicting R&D-source denominators are still unavailable for independent third-party recreation.
- An archival source check does not eliminate executive-selection endogeneity or validate causal treatment effects.

## Implication for models

PHD is a representative-team **presence** indicator, not a PhD-CEO identity indicator in multiple-representative firms. Main and interaction regressions retain the historical PHD values. The presence rates are 186/494 (37.7%) in SINGLE=1 and 83/229 (36.2%) in SINGLE=0. A binary SINGLE adjustment does not control for exact representative count among multi-representative firms.
