# Status of separate automated filing comparison (not the author's manual ledger)

**Confirmed by author:** All preserved firm-year SINGLE and PHD variables were
individually checked by reading the companies' business reports. For PHD=1,
**at least one** registered representative director in the relevant firm-year
must hold an awarded doctoral degree; no more than one holder is required.

The *separately generated*, partially populated OpenDART crosswalk has 18 rows
containing alternative proposed classifications. Its 7 SINGLE mismatches and
11 PHD mismatches affect 15 distinct firm-years. Both versions use an any-PhD
coding threshold, but the same year-end roster, corporate identifier, document
revision, award status and legal registration status have NOT been demonstrated.
The alternative file's column suffix `_corrected` is a historical file label,
**not a formally adjudicated correction**.

`outputs/secondary_18_case_reconciliation_template.csv` preserves historical and
secondary values side-by-side and provides empty fields for source accession,
date matching, roster, awarded-degree evidence and author-resolution notes.
**No author-coded values have been changed**. The 705 other observations are
absent from *this automatic crosswalk*, not from the author's filing checks.
One cannot calculate source-coding error rates from this exercise.
