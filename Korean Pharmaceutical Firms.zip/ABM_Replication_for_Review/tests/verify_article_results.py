"""No model estimation: ensure article's numeric exhibits match package outputs."""
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
direct=pd.read_csv(ROOT/'outputs/direct_outcome_contrasts_primary_six.csv')
assert len(direct)==6
piv={(a.accounting,a.market,a.spec,a.term):a for a in direct.itertuples()}
checks={
 ('ROA','TQ','main','SINGLE'):(.61870,.00035,True),
 ('ROE','MB','main','SINGLE'):(.58184,.00245,True),
 ('ROA','TQ','main','PHD'):(-.27471,.23424,False),
 ('ROE','MB','main','PHD'):(-.28081,.23424,False),
 ('ROA','TQ','interaction','PHD_X_RDINT'):(-.49223,.02138,True),
 ('ROE','MB','interaction','PHD_X_RDINT'):(-.48837,.02138,True)}
for key,(coef,p,supported) in checks.items():
 r=piv[key];assert abs(r.beta_difference_standardized-coef)<.00002
 assert abs(r.p_holm_six-p)<.00002
 assert bool(r.significant_holm_05)==supported
sensitivity=pd.read_csv(ROOT/'outputs/timing_rd_sensitivity.csv')
def lookup(study,y,term):
 r=sensitivity.loc[(sensitivity.study==study)&(sensitivity.outcome==y)&(sensitivity.term==term)]
 assert len(r)==1;return r.iloc[0]
assert abs(lookup('prior_year_rd','TQ','PHD_x_L1RD').coef-.46812)<1e-4
assert abs(lookup('next_year_outcome','F1_ROE','SINGLE').coef+.03083)<1e-4
assert int(lookup('next_year_outcome','F1_ROE','SINGLE').nobs)==635
x=pd.read_csv(ROOT/'outputs/secondary_18_case_reconciliation_template.csv')
assert len(x)==18 and x.needs_single_review.sum()==7 and x.needs_phd_review.sum()==11
assert (x.review_decision=='NOT ADJUDICATED; author codes retained').all()
source=pd.read_csv(ROOT/'data/analysis_panel_raw.csv')
assert len(source)==723 and source.duplicated(['firm_id','year']).sum()==0
assert source.PHD.sum()==269 and source.SINGLE.sum()==494
print('PASS: article Table6/Table8 reported numeric values, status labels, PHD rule and panel cardinalities')
