"""Synthetic *code-path smoke test only*. Generates data in tempdir and deletes it.

NEVER use results from this script in the article. They are NOT empirical data.
"""
from pathlib import Path
import tempfile,shutil,subprocess,sys
import numpy as np
import pandas as pd
from importlib.util import module_from_spec,spec_from_file_location
SOURCE=Path(__file__).resolve().parents[1]
REQUIRED=['01_prepare_analysis_panel.py','02_main_models.py','08_figure1.py',
          '13_multiple_testing.py','16_outcome_contrast_tests.py',
          '17_timing_and_rd_robustness.py','19_annual_transition_windows.py']
with tempfile.TemporaryDirectory(prefix='abm_synthetic_code_check_') as td:
    root=Path(td)
    for name in ['code','schemas','documented_results']:
        shutil.copytree(SOURCE/name,root/name,ignore=shutil.ignore_patterns('__pycache__'))
    (root/'data').mkdir();(root/'outputs').mkdir()
    rng=np.random.default_rng(1729)
    rows=[];text=[]
    for i in range(20):
        for y in range(2015,2025):
            single=int((i+(y//2))%3>0)
            phd=int((i+y)%4>1)
            rd=float(rng.uniform(.002,.21))
            size=24.8+rng.uniform(0,2)
            roa=.02+.03*single-.01*rd+rng.normal(0,.025)
            tq=1+.36*phd+1.3*rd+rng.normal(0,.12)
            rows.append(dict(firm_id=f'firm_{i:03d}',year=y,stock_code=f'{i:06d}',ROA=roa,ROE=roa*1.7,
                TQ=tq,MB=tq*1.25,SINGLE=single,PHD=phd,BUS=int(i%2==0),LONGTEN=int(y>2019),RDINT=rd,
                SIZE=size,LEV=rng.uniform(.05,.55),CUR=rng.uniform(.9,5),GRW=rng.uniform(-.1,.3),
                CFO=rng.uniform(-.03,.15),AGE=3.5,FORN=rng.uniform(.0,.1),LARGEST=rng.uniform(.15,.6),
                BIG4=int(i%3==0),LOSS=int((y+i)%6==0),RD_EXP=rd*100,SALES=150,
                filing_id=f'fixture-{i}-{y}',source_snapshot_date='2026-10-01'))
            for k in range(8):
                text.append(dict(firm_id=f'firm_{i:03d}',year=y,section='risk' if k<3 else 'research',
                     machine_class=['positive','negative','neutral'][k%3],confidence=.7+.025*k,
                     sentence_hash=f'test-{i}-{y}-{k}',filing_date=f'{y+1}-03-20',filing_id=f'fake-{i}-{y}'))
    pd.DataFrame(rows).to_csv(root/'data'/'analysis_panel_raw.csv',index=False)
    pd.DataFrame(text).to_csv(root/'data'/'sentence_archive.csv',index=False)
    valid=[]
    for idx in range(90):
        lab=['negative','neutral','positive'][idx%3]
        valid.append(dict(sentence_id=f'test_{idx}',section='risk',machine_class=lab,rater1=lab,
                          rater2=lab,rater3=lab,sampling_weight=1))
    pd.DataFrame(valid).to_csv(root/'data'/'validation_ratings.csv',index=False)
    for filename in REQUIRED:
        proc=subprocess.run([sys.executable,str(root/'code'/filename)],cwd=root,capture_output=True,text=True)
        print(filename, 'PASS' if proc.returncode==0 else 'FAIL')
        if proc.returncode!=0:
            print(proc.stdout[-2500:],proc.stderr[-2500:])
            raise SystemExit('Synthetic test unexpectedly failed')
    # Predictive ML is deliberately not part of the upgraded observational article.
    # Do not spend smoke-test time tuning unreported forecasting models.
    print('All synthetic code-path checks succeeded; temp observations will be deleted.')
