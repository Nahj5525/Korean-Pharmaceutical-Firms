# ABM numerical replication materials (blinded review copy)

Study: **Governance Structure, Executive Credentials, and the Performance-Valuation Divide in Korean Pharmaceutical Firms**.

This package reproduces numerical regression exhibits from the **supplied coded numeric firm-year panel**, not the underlying manual archival coding from original reports. It contains no author identities, title page, or funding details.

## Run (Python >= 3.10)

```bash
python -m pip install -r requirements.txt
python code/run_all.py
python tests/verify_article_results.py
python tests/smoke_test.py
```

Run all commands from this folder. The first call performs 725-to-723 historical-input reconciliation and re-estimates firm/year fixed-effects models, paired contrasts, robustness checks, and Figure 1. The second checks reported Table 6/8 numeric values against reproduced CSVs and panel cardinalities. The last is **only a synthetic code-path smoke test** (fixture rows are never used in article results). `outputs/` stores the pre-run verified files, which can be recreated by running code. The `documented_results/` folder contains human-readable exhibit snapshots and provenance.

## What is covered

- Observations: 723 unique firm-years, 87 firms (2015-2024), derived from a preserved 725-row included input.
- Variables SINGLE (one registered representative director) and PHD (at least one registered representative director holds an awarded doctorate) are carried forward exactly from the supplied author-coded panel; no overwrite of disputed historical codes.
- Firm/year fixed effects; clustered standard errors; ROA, ROE, Tobin's Q proxy and market-to-book; R&D moderation; coefficient-difference tests; Holm adjustments; additional within-firm and timing checks.
- The 725-to-723 input step historically averaged two pairs of conflicting R&D-intensity values. Reproduction of that averaging choice **does not validate it against source filings**.

## What is NOT independently reproducible from this package

- The original 1,209-row sampling universe and direct third-party TS-2000 downloads; firm/director filing-to-code ledger underlying the authors' manual DART review.
- Filing-level decision on the two duplicate firm-year R&D observations.
- Complete representative director / doctorate source rechecking: an **auxiliary 18-case crosswalk** differs in 15 cases across SINGLE or PHD, and discrepancies have not been adjudicated; this neither proves nor disproves the author-coded series.
- Source R&D expenditure and sales needed to estimate a true R&D/sales alternative denominator.
- Earlier text-sentiment extensions: omitted from the submitted article because raw sentence and rating records are unavailable.
- Causal claims or persistence/forecast claims are not warranted by panel associations.

## Data status / responsible sharing

The CSVs are derived from materials previously supplied to the researcher. Company identifiers are replaced with stable numeric `firm_id`, but the values originate in licensed datasets and public filings. Public deposition or distribution of the underlying derived data may require a check of TS-2000 licence terms and other applicable rights; **reviewer access is not an assertion of permission for open redistribution**. See `data/README_DATA_ACCESS.md`.

The core article results can be reproduced with the files in this folder and the standard requirements; optional prediction, SHAP and bootstrap modules are not needed for the submitted article.
